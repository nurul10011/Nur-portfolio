// JUMP ANIMATION ON PROFILE PICTURE CLICK
function jumpProfile(element) {
    element.classList.remove('jump');
    void element.offsetWidth;
    element.classList.add('jump');
    setTimeout(() => {
        element.classList.remove('jump');
    }, 600);
}

// CALL PHONE
function callPhone() {
    window.location.href = 'tel:+8801406383694';
}

// SEND EMAIL
function sendEmail() {
    window.location.href = 'mailto:antormit05@gmail.com';
}

// OPEN LOCATION IN GOOGLE MAPS
function openMap() {
    const latitude = 23.8248;
    const longitude = 90.3789;
    const mapsUrl = `https://maps.google.com/?q=${latitude},${longitude}`;
    window.open(mapsUrl, '_blank');
}

// SCROLL FUNCTIONS
function scrollToProjects() {
    const projectsSection = document.getElementById('projects');
    if (projectsSection) {
        projectsSection.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

function scrollToContact() {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
        contactSection.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// SMOOTH SCROLL FOR NAVIGATION
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const targetId = this.getAttribute('href').substring(1);
        const target = document.getElementById(targetId);
        
        if (target) {
            const navLinks = document.querySelector('.nav-links');
            if (navLinks.classList.contains('active')) {
                navLinks.classList.remove('active');
            }
            
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// HAMBURGER MENU
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        hamburger.classList.toggle('active');
    });
}

document.addEventListener('click', (e) => {
    const navbar = document.querySelector('.navbar');
    if (!navbar.contains(e.target)) {
        navLinks?.classList.remove('active');
        hamburger?.classList.remove('active');
    }
});

// NAVBAR ACTIVE LINK HIGHLIGHT
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-links a');
    
    let current = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        
        if (window.pageYOffset >= sectionTop - 300) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('active');
        }
    });
});

// INTERSECTION OBSERVER FOR ANIMATIONS
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
            entry.target.style.filter = 'blur(0)';
        }
    });
}, observerOptions);

const projectCards = document.querySelectorAll('.project-card');
projectCards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.filter = 'blur(10px)';
    card.style.transition = `opacity 0.6s ease ${index * 0.15}s, transform 0.6s ease ${index * 0.15}s, filter 0.6s ease ${index * 0.15}s`;
    observer.observe(card);
});

const contactCards = document.querySelectorAll('.contact-card');
contactCards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.filter = 'blur(10px)';
    card.style.transition = `opacity 0.6s ease ${index * 0.15}s, transform 0.6s ease ${index * 0.15}s, filter 0.6s ease ${index * 0.15}s`;
    observer.observe(card);
});

const infoCards = document.querySelectorAll('.info-card');
infoCards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateX(-30px)';
    card.style.transition = `opacity 0.6s ease ${index * 0.1}s, transform 0.6s ease ${index * 0.1}s`;
    observer.observe(card);
});

// MOUSE FOLLOW EFFECT
const heroContent = document.querySelector('.hero-content');
if (heroContent) {
    document.addEventListener('mousemove', (e) => {
        const floatShapes = document.querySelectorAll('.floating-shape');
        
        floatShapes.forEach(shape => {
            const shapeRect = shape.getBoundingClientRect();
            const shapeCenterX = shapeRect.left + shapeRect.width / 2;
            const shapeCenterY = shapeRect.top + shapeRect.height / 2;
            
            const angle = Math.atan2(e.clientY - shapeCenterY, e.clientX - shapeCenterX);
            const distance = 10;
            
            const offsetX = Math.cos(angle) * distance;
            const offsetY = Math.sin(angle) * distance;
            
            shape.style.transform = `translate(${offsetX}px, ${offsetY}px)`;
        });
    });
}

// PARALLAX EFFECT
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const floatShapes = document.querySelectorAll('.floating-shape');
    
    floatShapes.forEach((shape, index) => {
        const speed = 0.5 + (index * 0.1);
        shape.style.transform = `translateY(${scrolled * speed}px)`;
    });
});

// PAGE LOAD
window.addEventListener('load', () => {
    console.log('✓ Portfolio loaded successfully!');
    console.log('✓ Click the profile picture to see it jump!');
    console.log('✓ Click phone, email, or location buttons!');
});

// KEYBOARD SHORTCUTS
document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'h') {
        e.preventDefault();
        document.getElementById('home').scrollIntoView({ behavior: 'smooth' });
    }
    
    if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault();
        document.getElementById('projects').scrollIntoView({ behavior: 'smooth' });
    }
    
    if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        e.preventDefault();
        document.getElementById('contact').scrollIntoView({ behavior: 'smooth' });
    }
});

// CONSOLE MESSAGES
console.log('%c✨ Welcome to Nurul Islam\'s Portfolio ✨', 'color: #00d4ff; font-size: 16px; font-weight: bold;');
console.log('%cNational University of Bangladesh | Mirpur, Dhaka', 'color: #7c3aed; font-size: 12px;');
console.log('%cEmail: antormit05@gmail.com | Phone: 01406383694', 'color: #10b981; font-size: 12px;');